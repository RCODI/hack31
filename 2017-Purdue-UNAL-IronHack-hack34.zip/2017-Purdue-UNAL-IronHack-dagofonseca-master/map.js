function myMap() {
	var mapOptions = {
		center: new google.maps.LatLng(41.870800, -87.650500),
		zoom: 13,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	var map = new google.maps.Map(document.getElementById("map"), mapOptions);
	var marker = new google.maps.Marker({ //Line 1
		position: {lat: 41.870800, lng: -87.650500}, //Line2: Location to be highlighted
		map: map,//Line 3: Reference to map object
		title: 'Department of Computer Science,University of Illinois, Chicago' //Line 4: Title to be given
	})	
}

var infowindow = new google.maps.InfoWindow({
                       content: ""
                   });
google.maps.event.addListener(marker, 'click', function() {
   infowindow.setContent("Chicago City");
                       infowindow.open(map, marker);
                   });