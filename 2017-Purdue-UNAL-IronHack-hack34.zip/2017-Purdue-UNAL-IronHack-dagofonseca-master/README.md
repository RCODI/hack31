
1. Chicago's rents
2. closeness, segurity, clear
3. I don't use any dataset yet, but I think use "Affordable Rental Housing Developments"
4. Brief Description 
The project "Chicago's rents" aim to be the solution problems of new students of University of Illinois which move to chicago.

*Map View:
   i.Yes
   ii.Yes
   iii.Yes
   iv.No
   v.No

*Data Visualizaton
   i.No
   ii.No

*Interaction Form:
   i.No
   ii.No
   iii.No
   iv.No
   v.No

5.None build case

6.Chrome and Firefox

7.None

