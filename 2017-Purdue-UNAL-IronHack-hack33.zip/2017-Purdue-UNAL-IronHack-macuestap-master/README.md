## Best Chicago Options

The first idea I had watching the information and finding the data sets on data.gov, was to take
the points given by the page about places where a crime was made. This way find where were the
safest places and the risky ones. But is not cool to open a page and see crime scenes, so I changed
to first showing the best weather, then the nearest locations and finally the safest places.


## Keywords

weather, safe, near


## Datasets
1. Custom datasets of https://www.ncdc.noaa.gov with information near Purdue University.
2. Crimes - 2001 to present. https://catalog.data.gov/dataset/crimes-2001-to-present-398a4. Not used totally yet.

Description of the datasets and function design

[Y] Do you use the primary dataset ”online climate data” from data.gov?
[Y] [List] Are all these datasets from data.gov or data.indy.gov?

Brief Description:
Starting with a map showing the best weather, continues with another map showing dangerous places
based on the crimes made on that zone.

Fill in the structured description:

Map View:

[Y/ Basic Map with specific location (your map is located in a meaningful place, city of west lafayette for example)
[Y] Markers for location of markets
[No yet] Labels for markets' names
[No yet] InfoWindow to show detail information of a market
[No yet] [describe] Any other cover on the map (for example, cloud cover to show the weather effect)


## Frameworks and tools used

In this project I used angular 2 and Bootstrap.

For creating the project I used Angular 2, with the angular compiler angular-cli. Here is the README that is created automatically when you create a new project with angular-cli:



This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.0.0-rc.0.

Development server
Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive/pipe/service/class/module`.

Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

 Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `ng serve`.

Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


## -------
## Additional Comment
Even I'm grateful for this opportunity, I would like to say that the times that requires every iteration is not
enough. There's a lot of excellent programmers that are able to create applications in short time but there are
others that are learning and need more time to complete the assignments.
