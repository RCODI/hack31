Hello,

I can't see this repository for associated with Microsoft Azure, maybe the problem can be permissions, I have full permissions under this repository ? 

Other question is, the price is obtained by dataset or we give a price considering differents aspect? Because I not find dataset with rent house with Price.
